# OnEx
An OEP that is about developing an online examination system using the concepts of advanced Java
